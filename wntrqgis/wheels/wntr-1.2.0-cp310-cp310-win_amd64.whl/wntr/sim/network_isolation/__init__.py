"""The network isolation package (SWIG)."""

from wntr.sim.network_isolation.network_isolation import check_for_isolated_junctions, get_long_size
